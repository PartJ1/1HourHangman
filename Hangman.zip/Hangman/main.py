import random

with open('words.txt') as file:
    words = file.readlines()
    word = words[random.randint(0, len(words) - 1)].strip().lower()

word_dash = (len(word)) * '_'
letter_bool = False
count = 10
lose = False

while word != word_dash and lose is False:
    print(word_dash)
    letter_guess = input("Letter: ")

    for i, j in enumerate(word):
        if j == letter_guess:
            word_dash = list(word_dash)
            word_dash[i] = letter_guess
            word_dash = "".join(word_dash)
            letter_bool = True

    if letter_bool is False:
        count -= 1
        print('You have %s guesses left' % count)

    letter_bool = False

    if count == 0:
        lose = True
        pass

if lose is True:
    print('\nYou LOSE the word was %s' % word)
else:
    print('\nWell done the word was %s' % word_dash)

input()
